import {useState} from "react";
import axios from "axios";
import './App.css';
const URL = "https://gmail.googleapis.com/gmail/v1/users/";
const messages = "Thank you for subscribing the learning era"

function App() {
  const [email, setEmail] = useState("");
  const [response, setResponse] = useState(undefined);
  const debounce = (delay = 100, fn) =>{
    let timer;
    return  (...args)=> {
      if (timer){
        clearTimeout(timer);
      } else {
        timer = setTimeout(()=>{
          fn.apply(this, ...args);
        }, delay)
      }
    }
  }

  const handleKeyUp = (event)=>{
    let value = event.target.value;
    debounce(100, setEmail(value));
  }

  const handleSubmit = () =>{
    axios.post(`${URL}${email}/${messages}/send`)
        .then(res => {
          const {data, status} = res;
          if (status === 200){
            setResponse(`Subscription is done successfully ${data}`);
          } else {
            setResponse("Something went wrong. Please try again .. !!")
          }
        }).catch(err => setResponse("Something went wrong. Please try again .. !!"))
      // setResponse(`Subscription is done successfully`);
  }

  return (
    <div className="App">
      <header>
        <h3>Learning Era</h3>
        <h3>Subscription Form</h3>
      </header>
      <main>
        <input onKeyUp={(event)=> handleKeyUp(event)} placeholder={"Enter Email"}/>
        <button onClick={()=>handleSubmit()}>Submit</button>
      </main>
      <section>
        {
          response ? <h4 className="error">{response}</h4>
              : null
        }
      </section>
    </div>
  );
}

export default App;
