<!-- AUTO-GENERATED-CONTENT:START (STARTER) -->
<h1 align="center">
 🧬 Biometrics Authentication app tutorial
</h1>
Source code for the Biometrics Authentication app built in the <a href="https://youtu.be/qW1wQwHmoTI">YouTube tutorial</a>

Access the three-part written content here:
- [Biometrics Authentication app Part 1](https://designcode.io/quick-apps-swiftui-biometrics-auth-1)
- [Biometrics Authentication app Part 2](https://designcode.io/quick-apps-swiftui-biometrics-auth-2)
- [Biometrics Authentication app Part 3](https://designcode.io/quick-apps-swiftui-biometrics-auth-3)  
  
<!-- AUTO-GENERATED-CONTENT:END -->
