//
//  AuthenticatorDemoApp.swift
//  AuthenticatorDemo
//
//  Created by Stephanie Diep on 2021-12-15.
//

import SwiftUI

@main
struct AuthenticatorDemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
